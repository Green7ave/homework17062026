﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

using var client = new HttpClient();
var cacheUrl = "https://httpbin.org/cache/3600";

Console.WriteLine("=== ПЕРШИЙ ЗАПИТ (Отримуємо ресурс і заголовки валідації) ===");
var response1 = await client.GetAsync(cacheUrl);

var etag = response1.Headers.ETag?.Tag ?? "не знайдено";
var lastModified = response1.Content.Headers.LastModified;
var contentLength1 = response1.Content.Headers.ContentLength ?? 0;

Console.WriteLine($"Статус: {response1.StatusCode}");
Console.WriteLine($"Розмір контенту (Content-Length): {contentLength1} байт");
Console.WriteLine($"Отриманий ETag: {etag}");
Console.WriteLine($"Отриманий Last-Modified: {lastModified}");
Console.WriteLine(new string('-', 50));

Console.WriteLine("=== ДРУГИЙ ЗАПИТ (Надсилаємо умовні заголовки для перевірки кешу) ===");
var request2 = new HttpRequestMessage(HttpMethod.Get, cacheUrl);

if (etag != "не знайдено")
{
    request2.Headers.IfNoneMatch.ParseAdd(etag);
}
if (lastModified.HasValue)
{
    request2.Headers.IfModifiedSince = lastModified;
}

var response2 = await client.SendAsync(request2);
var contentLength2 = response2.Content.Headers.ContentLength ?? 0;

Console.WriteLine($"Статус: {response2.StatusCode}");
Console.WriteLine($"Розмір контенту в 304 відповіді: {contentLength2} байт");

if (response2.StatusCode == HttpStatusCode.NotModified)
{
    Console.WriteLine("✓ Успіх! Кешування працює. Сервер повернув 304 Not Modified, тіло відповіді пусте.");
}
else
{
    Console.WriteLine("✗ Обробка кешу не спрацювала.");
}