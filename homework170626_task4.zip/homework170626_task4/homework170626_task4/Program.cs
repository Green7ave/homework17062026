﻿using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

// 1. Створюємо CookieContainer для автоматичного збереження та відправки кук
var cookieContainer = new CookieContainer();

// 2. Налаштовуємо HttpClientHandler, щоб він використовував наш контейнер
var handler = new HttpClientHandler { CookieContainer = cookieContainer };

// 3. Ініціалізуємо HttpClient
using var client = new HttpClient(handler);

Console.WriteLine("=== ЗАПИТ 1: Отримання та встановлення кук ===");
var setCookieUrl = "https://httpbin.org/cookies/set?user=student&token=xyz789";
var response1 = await client.GetAsync(setCookieUrl);
Console.WriteLine($"Статус першого запиту: {response1.StatusCode}");

// 5. Виводимо те, що зберіг CookieContainer
var targetUri = new Uri("https://httpbin.org");
var cookies = cookieContainer.GetCookies(targetUri);
Console.WriteLine($"\nЗбережено кук в контейнері: {cookies.Count}");
foreach (Cookie cookie in cookies)
{
    Console.WriteLine($" - Ім'я: {cookie.Name}");
    Console.WriteLine($"   Значення: {cookie.Value}");
    Console.WriteLine($"   Домен: {cookie.Domain}");
    Console.WriteLine($"   Шлях: {cookie.Path}");
    Console.WriteLine($"   Термін дії: {(cookie.Expired ? "Закінчився" : cookie.Expires.ToString())}");
    Console.WriteLine();
}

Console.WriteLine("=== ЗАПИТ 2: Перевірка відправки кук на сервер ===");
var checkCookieUrl = "https://httpbin.org/cookies";
var response2 = await client.GetAsync(checkCookieUrl);
var body = await response2.Content.ReadAsStringAsync();

Console.WriteLine($"\nСервер повернув JSON (він бачить наші куки):");
Console.WriteLine(body);